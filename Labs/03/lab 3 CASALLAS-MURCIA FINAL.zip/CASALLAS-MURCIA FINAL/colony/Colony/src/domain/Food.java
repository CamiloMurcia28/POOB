package domain;

/**
 * The Food class from entity
 *
 * @author  Jeisson Casallas & Camilo Murcia
 * @version 1.0
 */
public final class Food  implements Entity{
    /**
     * Realiza una acción de la comida.
     */
    public void act(){
    }
}
