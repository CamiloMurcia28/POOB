package ColonyTest;
import domain.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
/**
 * The test class PersistanceTest.
 *
 * @author  Jeisson Casallas & Camilo Murcia
 * @version 1.0
 */
public class PersistanceTest{
    private Colony colony;
    private static final String TEST_SAVE_PATH = "C:/Users/User/Desktop/LAB 6/colony";
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp(){
        colony=new Colony();
    }
    
    //PRUEBAS SAVE 
    
    
    @Test
     public void testSave00(){
        try {
            Colony colony = new Colony();
            Path tempDir = Files.createTempDirectory("colony_test");
            File saveFile = new File(tempDir.toFile(), "colony_save.tmp");

            colony.save00(saveFile);

            assertTrue(saveFile.exists());

        } catch (ColonyException e) {
            fail("No se esperaba una excepción aquí: " + e.getMessage());
        } catch (Exception e) {
            fail("Ocurrió un error inesperado: " + e.getMessage());
        }
    }
    
    @Test
    public void testSave01() {
        try {
            Colony originalColony = new Colony();
            originalColony.createEntity("Ant", 1, 2);
            originalColony.createEntity("Food", 3, 4);

            File tempFile = File.createTempFile("colony_test_save", ".dat");
            tempFile.deleteOnExit();

            originalColony.save01(tempFile);

            assertEquals(true, tempFile.exists());

        } catch (IOException | ColonyException e) {
            fail("No se esperaba una excepción aquí: " + e.getMessage());
        }
    }

    @Test
    public void testSave01WithInvalidFile() {
        try {
            Colony originalColony = new Colony();
            originalColony.createEntity("Ant", 1, 2);
            originalColony.createEntity("Food", 3, 4);

            File invalidFile = new File("/invalid/directory/colony_test_save.dat");

            originalColony.save01(invalidFile);

            fail("Se esperaba una excepción pero no se lanzó.");

        } catch (ColonyException e) {
            assertEquals(ColonyException.ARCHIVO_NO_ENCONTRADO, e.getMessage());

        } catch (Exception e) {
            fail("Ocurrió un error inesperado: " + e.getMessage());
        }
    }

    
    
    //PRUEBAS OPEN
    @Test
    public void testOpen00() {
        try {
            // Crea una instancia de Colony para guardarla en un archivo temporal
            Colony originalColony = new Colony();

            // Guarda la instancia en un archivo temporal
            Path tempDir = Files.createTempDirectory("colony_test");
            File tempFile = new File(tempDir.toFile(), "colony_save.tmp");
            originalColony.save00(tempFile);

            // Llama al método open00 para cargar la instancia desde el archivo temporal
            Colony loadedColony = Colony.open00(tempFile);

            // Verifica que la instancia cargada no sea nula y sea igual a la original
            assertNotNull(loadedColony);

        } catch (ColonyException | IOException e) {
            fail("No se esperaba una excepción aquí: " + e.getMessage());
        }
    } 
    
    @Test
    public void testOpen01FileNotFound() {
        try {
            // Intenta abrir un archivo que no existe
            File nonExistentFile = new File("non_existent_file.dat");
            Colony.open01(nonExistentFile);
            // Si no se lanza una excepción, la prueba falla
            fail("Se esperaba una excepción de ARCHIVO_NO_ENCONTRADO.");
        } catch (ColonyException e) {
            // Verifica si la excepción lanzada es la correcta
            assertEquals(ColonyException.ARCHIVO_NO_ENCONTRADO, e.getMessage());
        }
    }

    @Test
    public void testOpen01CorruptFile() {
        try {
            // Crea un archivo vacío (archivos vacíos se consideran corruptos para este ejemplo)
            File corruptFile = File.createTempFile("corrupt_file", ".dat");
            corruptFile.deleteOnExit();
            Colony.open01(corruptFile);
            fail("Se esperaba una excepción de ERROR_ENTRADA");
        } catch (ColonyException e) {
            assertEquals(ColonyException.ERROR_ENTRADA, e.getMessage());
        } catch (IOException e) {
            fail("No se esperaba una excepción de IOException aquí.");
        }
    }
    
    
    //PRUEBA IMPORT

    @Test
    public void testImport00() {
        try {
            Colony originalColony = new Colony();
            originalColony.createEntity("Ant", 1, 2);
            originalColony.createEntity("Food", 3, 4);
            
            File tempFile = File.createTempFile("colony_test_import", ".txt");
            tempFile.deleteOnExit();

            originalColony.export00(tempFile);

            Colony importedColony = new Colony();

            importedColony.import00(tempFile);
            
            assertTrue(tempFile.exists());

        } catch (IOException | ColonyException e) {
            fail("No se esperaba una excepción aquí: " + e.getMessage());
        }
    }
    

    public void testImport01WithInvalidFile() {
        try {
            Colony colony = new Colony();

            File invalidFile = new File("/invalid/directory/nonexistent_file.txt");
            colony.import01(invalidFile);

            fail("Se esperaba una excepción pero no se lanzó.");

        } catch (ColonyException e) {
            assertEquals(ColonyException.ARCHIVO_NO_ENCONTRADO, e.getMessage());

        } catch (Exception e) {
            fail("Ocurrió un error inesperado: " + e.getMessage());
        }
    }
    

    
    //PRUEBA EXPORT
    
    @Test
    public void testExport00() {
        try {
            Colony originalColony = new Colony();
            originalColony.createEntity("Ant", 1, 2);
            originalColony.createEntity("Food", 3, 4);
            
            File tempFile = File.createTempFile("colony_test_export", ".txt");
            tempFile.deleteOnExit();
    
            originalColony.export00(tempFile);
    
            assertTrue(tempFile.exists());
    
        } catch (IOException | ColonyException e) {
            fail("No se esperaba una excepción aquí: " + e.getMessage());
        }
    }
    
    @Test
    public void testExport01() {
        try {
            Colony colony = new Colony();
            colony.createEntity("Ant", 1, 2);
            colony.createEntity("Food", 3, 4);
    
            File tempFile = File.createTempFile("colony_test_export", ".txt");
            tempFile.deleteOnExit();
    
            colony.export01(tempFile);
    
            assertTrue(tempFile.exists());
    
        } catch (IOException | ColonyException e) {
            fail("No se esperaba una excepción aquí: " + e.getMessage());
        }
    }

}


