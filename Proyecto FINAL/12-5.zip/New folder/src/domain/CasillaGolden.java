package domain;
public class CasillaGolden extends Casilla {

    public CasillaGolden(int row, int col){
        super(row, col);
    }

}