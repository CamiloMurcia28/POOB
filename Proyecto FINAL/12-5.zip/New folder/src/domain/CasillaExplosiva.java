package domain;
public class CasillaExplosiva extends Casilla {

    public CasillaExplosiva(int row, int col){
        super(row, col);
    }

}