package domain;
public class CasillaTeleport extends Casilla {

    public CasillaTeleport(int row, int col){
        super(row, col);
    }

}